# Bu sürümde küçültme (minify) kapalı olduğu için özel kural gerekmiyor.
