package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.sin

private val Cyan = Color(0xFF39D0FF)
private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF111B2E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, background = Bg, surface = Panel,
                    onBackground = Color.White, onSurface = Color.White, onPrimary = Bg,
                )
            ) { Root() }
        }
    }

    override fun onStart() { super.onStart(); Bus.appVisible = true }
    override fun onStop() { super.onStop(); Bus.appVisible = false }
}

private fun micOk(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

private fun notifOk(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

private fun launch(ctx: Context, i: Intent) {
    try { ctx.startActivity(i) } catch (e: Exception) { Toast.makeText(ctx, "Açılamadı", Toast.LENGTH_SHORT).show() }
}

@Composable
fun Root() {
    var settings by remember { mutableStateOf(false) }
    BackHandler(enabled = settings) { settings = false }
    Box(Modifier.fillMaxSize().background(Bg)) {
        if (settings) SettingsScreen { settings = false } else MainScreen { settings = true }
    }
}

@Composable
fun MainScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val state by Bus.state.collectAsStateWithLifecycle()
    val heard by Bus.heard.collectAsStateWithLifecycle()
    val reply by Bus.reply.collectAsStateWithLifecycle()
    val info by Bus.info.collectAsStateWithLifecycle()
    val ttsMissing by Bus.ttsMissing.collectAsStateWithLifecycle()
    val cfg by Prefs.cfg.collectAsStateWithLifecycle()
    var rationale by remember { mutableStateOf(false) }
    var pendingAction by remember { mutableStateOf(A_START) }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (micOk(ctx)) JarvisService.send(ctx, pendingAction)
        else Toast.makeText(ctx, "Mikrofon izni verilmedi", Toast.LENGTH_LONG).show()
    }

    fun begin(action: String) {
        if (micOk(ctx)) JarvisService.send(ctx, action) else { pendingAction = action; rationale = true }
    }

    val running = state != JState.OFF
    val micOn = state == JState.WAITING || state == JState.LISTENING
    val wakeLabel = if (cfg.heyOnly) "Hey JARVIS" else "JARVIS"
    val status = when (state) {
        JState.OFF -> "Kapalı"
        JState.WAITING -> "\"$wakeLabel\" demenizi bekliyor"
        JState.LISTENING -> "Sizi dinliyorum"
        JState.PROCESSING -> "İşleniyor…"
        JState.SPEAKING -> "Konuşuyor"
        JState.SLEEPING -> if (cfg.wakeEnabled) "Uykuda — mikrofon kapalı" else "Sesle uyandırma kapalı — 🎤 düğmesini kullanın"
        JState.PAUSED -> "Ekran kapalı — dinleme duraklatıldı"
    }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("J.A.R.V.I.S", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Cyan)
            TextButton(onClick = onSettings) { Text("Ayarlar") }
        }
        Text(
            if (micOn) "● MİKROFON AÇIK" else "○ Mikrofon kapalı",
            color = if (micOn) Color(0xFFFF6B6B) else Color(0xFF8A97AB), fontSize = 13.sp,
        )
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Orb(state, Modifier.size(260.dp))
        }
        Text(status, fontSize = 20.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        if (heard.isNotEmpty()) Text("Siz: $heard", color = Color(0xFFB9C4D6), textAlign = TextAlign.Center)
        if (reply.isNotEmpty()) Text("JARVIS: $reply", color = Cyan, textAlign = TextAlign.Center)
        if (ttsMissing) Text("⚠ Türkçe ses paketi yok. Ayarlar'dan yükleyin.", color = Color(0xFFFFB84D), fontSize = 13.sp, textAlign = TextAlign.Center)
        if (info.isNotEmpty()) Text(info, color = Color(0xFF8A97AB), fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { if (running) JarvisService.send(ctx, A_STOP) else begin(A_START) }) {
                Text(if (running) "Durdur" else "Başlat")
            }
            OutlinedButton(onClick = { begin(A_MANUAL) }) { Text("🎤 Konuş") }
        }
    }

    if (rationale) {
        AlertDialog(
            onDismissRequest = { rationale = false },
            title = { Text("Mikrofon izni") },
            text = {
                Text(
                    "JARVIS'in \"JARVIS\" kelimesini duyabilmesi için mikrofonu dinlemesi gerekir. " +
                        "Dinleme açıkken ekranda ve bildirimde \"Mikrofon açık\" yazar; Android da yeşil gösterge çıkarır. " +
                        "Ses kaydedilmez ve saklanmaz. Konuşma tanımayı Android'in sistem servisi (Google) yapar; " +
                        "çevrimdışı Türkçe paket yüklüyse ses cihazdan çıkmaz."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    rationale = false
                    perms.launch(
                        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
                        else arrayOf(Manifest.permission.RECORD_AUDIO)
                    )
                }) { Text("İzin ver") }
            },
            dismissButton = { TextButton(onClick = { rationale = false }) { Text("Vazgeç") } },
        )
    }
}

@Composable
fun Orb(state: JState, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "orb")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "p")
    val color = when (state) {
        JState.WAITING -> Cyan
        JState.LISTENING -> Color(0xFF4DFFB4)
        JState.PROCESSING -> Color(0xFFFFB84D)
        JState.SPEAKING -> Color(0xFFB48CFF)
        else -> Color(0xFF55657A)
    }
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val tau = (2 * Math.PI).toFloat()
        val core = when (state) {
            JState.WAITING -> r * (0.28f + 0.03f * sin(p * tau))
            JState.LISTENING -> r * (0.30f + 0.05f * sin(p * tau * 2f))
            JState.SPEAKING -> r * (0.30f + 0.06f * sin(p * tau * 4f))
            JState.PROCESSING -> r * 0.28f
            else -> r * 0.22f
        }
        drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.5f), Color.Transparent), center = c, radius = r), radius = r, center = c)
        drawCircle(color, radius = core, center = c)
        drawCircle(color.copy(alpha = 0.6f), radius = r * 0.62f, center = c, style = Stroke(3f))
        if (state == JState.LISTENING) {
            for (i in 0..2) {
                val q = (p + i / 3f) % 1f
                drawCircle(color.copy(alpha = 1f - q), radius = r * (0.35f + 0.65f * q), center = c, style = Stroke(3f))
            }
        }
        if (state == JState.PROCESSING) {
            for (k in 0..1) {
                drawArc(
                    color, startAngle = p * 360f + k * 180f, sweepAngle = 90f, useCenter = false,
                    topLeft = Offset(c.x - r * 0.8f, c.y - r * 0.8f), size = Size(r * 1.6f, r * 1.6f),
                    style = Stroke(8f, cap = StrokeCap.Round),
                )
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (sub != null) Text(sub, fontSize = 12.sp, color = Color(0xFF8A97AB))
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cfg by Prefs.cfg.collectAsStateWithLifecycle()
    val running = Bus.state.collectAsStateWithLifecycle().value != JState.OFF
    val mic = micOk(ctx)

    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(20.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Geri") }
            Text("Ayarlar", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        SwitchRow("Sesle uyandırma", "Kapalıysa yalnızca 🎤 düğmesiyle konuşursunuz", cfg.wakeEnabled) { v -> Prefs.update { it.copy(wakeEnabled = v) } }
        Text("Uyandırma kelimesi", fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !cfg.heyOnly, onClick = { Prefs.update { it.copy(heyOnly = false) } }, label = { Text("JARVIS") })
            FilterChip(selected = cfg.heyOnly, onClick = { Prefs.update { it.copy(heyOnly = true) } }, label = { Text("Hey JARVIS") })
        }
        SwitchRow(
            "Ekran kapalıyken dinleme",
            "Garanti değildir. Redmi/HyperOS pil kısıtlaması servisi durdurabilir; aşağıdaki pil ayarını \"Kısıtlama yok\" yapın.",
            cfg.screenOff,
        ) { v -> Prefs.update { it.copy(screenOff = v) } }
        SwitchRow("Sesli yanıtlar", null, cfg.voice) { v -> Prefs.update { it.copy(voice = v) } }
        Text("Konuşma hızı", fontSize = 14.sp)
        Slider(value = cfg.rate, onValueChange = { v -> Prefs.update { it.copy(rate = v) } }, valueRange = 0.6f..1.5f)
        SwitchRow("Sürekli konuşma modu", "Komuttan sonra uyandırma kelimesi beklemeden dinlemeye devam eder", cfg.continuous) { v -> Prefs.update { it.copy(continuous = v) } }
        OutlinedTextField(
            value = cfg.city, onValueChange = { v -> Prefs.update { it.copy(city = v) } },
            label = { Text("Hava durumu şehri") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )

        Spacer(Modifier.height(16.dp))
        Text("Yapay zekâ", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        SwitchRow(
            "Ücretsiz yapay zekâ (anahtarsız)",
            "Komutlara uymayan sorular üçüncü taraf ücretsiz bir servise (Pollinations) metin olarak gider. ChatGPT değildir, kararsız olabilir.",
            cfg.freeAi,
        ) { v -> Prefs.update { it.copy(freeAi = v) } }
        Text("ChatGPT (isteğe bağlı)", fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        OutlinedTextField(
            value = cfg.apiKey, onValueChange = { v -> Prefs.update { it.copy(apiKey = v.trim()) } },
            label = { Text("OpenAI API anahtarı") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        )
        OutlinedTextField(
            value = cfg.model, onValueChange = { v -> Prefs.update { it.copy(model = v.trim()) } },
            label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )
        Text(
            if (cfg.apiKey.isBlank()) "Anahtar yok: ChatGPT kapalı, yukarıdaki ücretsiz servis kullanılır. Daha sağlam cevap için platform.openai.com'dan API anahtarı alabilirsiniz (ChatGPT Plus'tan ayrı, kullanıma göre ücretli)."
            else "ChatGPT açık. Yerleşik komutlara uymayan her şey ChatGPT'ye sorulur. Anahtar yalnızca bu telefonda saklanır; ChatGPT'ye sadece konuştuğunuzun yazıya dökülmüş metni gider, ses gitmez.",
            fontSize = 12.sp, color = Color(0xFF8A97AB),
        )

        Spacer(Modifier.height(16.dp))
        Text("Durum", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Mikrofon izni: " + if (mic) "verildi" else "verilmedi", color = if (mic) Color(0xFF4DFFB4) else Color(0xFFFFB84D))
        Text("Bildirim izni: " + if (notifOk(ctx)) "verildi" else "verilmedi")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                launch(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            }) { Text("Uygulama ayarları") }
            OutlinedButton(onClick = { launch(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Pil ayarı") }
        }
        OutlinedButton(onClick = {
            launch(ctx, Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
        }) { Text("Türkçe ses paketi yükle") }

        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (mic) JarvisService.send(ctx, A_TEST)
            else Toast.makeText(ctx, "Önce ana ekrandan Başlat'a basıp mikrofon izni verin", Toast.LENGTH_LONG).show()
        }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "Asistanı test et" else "Asistanı başlat ve test et") }

        Spacer(Modifier.height(16.dp))
        Text(
            "Gizlilik: Ses kaydedilmez veya saklanmaz. Mikrofon yalnızca dinleme açıkken kullanılır ve ekranda/bildirimde gösterilir. " +
                "Konuşma tanıma Android'in sistem servisi (Google) tarafından yapılır; çevrimdışı Türkçe paket yüklüyse ses cihazda işlenir. " +
                "İnternete hava durumu için şehir adı, ChatGPT açıksa soruların metni gönderilir.",
            fontSize = 12.sp, color = Color(0xFF8A97AB),
        )
    }
}
