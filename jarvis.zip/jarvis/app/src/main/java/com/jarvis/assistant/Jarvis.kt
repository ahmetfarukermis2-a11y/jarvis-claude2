package com.jarvis.assistant

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.AlarmClock
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale

const val A_START = "jarvis.start"
const val A_SLEEP = "jarvis.sleep"
const val A_STOP = "jarvis.stop"
const val A_MANUAL = "jarvis.manual"
const val A_TEST = "jarvis.test"

enum class JState { OFF, WAITING, LISTENING, PROCESSING, SPEAKING, SLEEPING, PAUSED }

/** Servis ile arayüz arasındaki ortak durum. */
object Bus {
    val state = MutableStateFlow(JState.OFF)
    val heard = MutableStateFlow("")
    val reply = MutableStateFlow("")
    val info = MutableStateFlow("")
    val ttsMissing = MutableStateFlow(false)
    @Volatile var appVisible = false
}

data class Cfg(
    val wakeEnabled: Boolean = true,
    val heyOnly: Boolean = false,
    val screenOff: Boolean = false,
    val voice: Boolean = true,
    val continuous: Boolean = false,
    val rate: Float = 1f,
    val city: String = "İstanbul",
    val apiKey: String = "",
    val model: String = "gpt-4o-mini",
    val freeAi: Boolean = true,
)

object Prefs {
    private lateinit var sp: SharedPreferences
    private val _cfg = MutableStateFlow(Cfg())
    val cfg: StateFlow<Cfg> = _cfg

    fun init(ctx: Context) {
        if (this::sp.isInitialized) return
        sp = ctx.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        _cfg.value = Cfg(
            wakeEnabled = sp.getBoolean("wake", true),
            heyOnly = sp.getBoolean("hey", false),
            screenOff = sp.getBoolean("screenOff", false),
            voice = sp.getBoolean("voice", true),
            continuous = sp.getBoolean("cont", false),
            rate = sp.getFloat("rate", 1f),
            city = sp.getString("city", "İstanbul") ?: "İstanbul",
            apiKey = sp.getString("key", "") ?: "",
            model = sp.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini",
            freeAi = sp.getBoolean("free", true),
        )
    }

    fun update(f: (Cfg) -> Cfg) {
        val n = f(_cfg.value)
        _cfg.value = n
        sp.edit()
            .putBoolean("wake", n.wakeEnabled).putBoolean("hey", n.heyOnly)
            .putBoolean("screenOff", n.screenOff).putBoolean("voice", n.voice)
            .putBoolean("cont", n.continuous).putFloat("rate", n.rate)
            .putString("city", n.city).putString("key", n.apiKey).putString("model", n.model).putBoolean("free", n.freeAi).apply()
    }
}

/** Türkçe metin yardımcıları. */
object Tr {
    val TR: Locale = Locale("tr", "TR")

    /** Küçük harfe çevirir, noktalamayı atar, Türkçe harfleri ASCII'ye indirger. */
    fun fold(s: String): String {
        val n = s.lowercase(TR)
            .replace(Regex("(?<=\\d)\\s*[x×*]\\s*(?=\\d)"), " çarpı ")
            .replace("+", " artı ")
            .replace(Regex("(?<=\\d)\\s*[-−–]\\s*(?=\\d)"), " eksi ")
            .replace(Regex("[/÷]"), " bölü ")
            .replace(Regex("[’'`´]"), " ")
            .replace(Regex("[^\\p{L}\\p{Nd}:. ]"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return n.map {
            when (it) {
                'ı' -> 'i'; 'ş' -> 's'; 'ç' -> 'c'; 'ğ' -> 'g'; 'ö' -> 'o'; 'ü' -> 'u'
                else -> it
            }
        }.joinToString("")
    }

    private val ones = arrayOf("sıfır", "bir", "iki", "üç", "dört", "beş", "altı", "yedi", "sekiz", "dokuz")
    private val tens = arrayOf("", "on", "yirmi", "otuz", "kırk", "elli", "altmış", "yetmiş", "seksen", "doksan")

    fun num(n: Int): String = when {
        n < 0 -> "eksi " + num(-n)
        n < 10 -> ones[n]
        n < 100 -> tens[n / 10] + (if (n % 10 == 0) "" else " " + ones[n % 10])
        n == 100 -> "yüz"
        else -> n.toString()
    }

    fun clock(h: Int, m: Int): String =
        if (m == 0) num(h) else num(h) + " " + (if (m < 10) "sıfır " else "") + num(m)

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    private val heys = setOf("hey", "hay", "hei", "hej", "ey")

    /** Uyandırma kelimesi geçiyorsa kelimeden sonrasını (komutu) döndürür, yoksa null. */
    fun wake(folded: String, heyOnly: Boolean): String? {
        val t = folded.split(" ").map { it.trim('.', ':') }.filter { it.isNotEmpty() }
        for (i in t.indices) {
            val w = t[i]
            if (w == "jarvis" || w == "carvis" || w == "cervis" || w == "jervis" || lev(w, "jarvis") <= 1) {
                if (heyOnly && (i == 0 || t[i - 1] !in heys)) continue
                return t.drop(i + 1).joinToString(" ")
            }
        }
        return null
    }

    private val words = mapOf(
        "sifir" to 0, "bir" to 1, "iki" to 2, "uc" to 3, "dort" to 4, "bes" to 5, "alti" to 6,
        "yedi" to 7, "sekiz" to 8, "dokuz" to 9, "on" to 10, "yirmi" to 20, "otuz" to 30,
        "kirk" to 40, "elli" to 50, "altmis" to 60, "yetmis" to 70, "seksen" to 80, "doksan" to 90,
    )
    private val ops = setOf("arti", "carpi", "kere", "eksi", "bolu")

    /** "7 30", "7.30", "yedi buçuk", "yirmi iki kırk beş" gibi ifadelerden saat çıkarır. */
    fun numberize(t: String): String {
        val toks = t.split(" ").filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var i = 0
        while (i < toks.size) {
            val w = toks[i]
            val v = words[w]
            if (v == null) { out.add(w); i++; continue }
            val nx = toks.getOrNull(i + 1)?.let { words[it] }
            val next = toks.getOrNull(i + 1)
            if (v >= 10 && nx != null && nx in 1..9) {
                out.add((v + nx).toString()); i += 2
            } else if (w == "bir" && nx == null && next != "bucuk" && next?.firstOrNull()?.isDigit() != true &&
                next !in ops && out.lastOrNull() !in ops
            ) {
                out.add(w); i++   // "bir alarm kur" gibi cümlelerde saat sanma
            } else {
                out.add(v.toString()); i++
            }
        }
        return out.joinToString(" ")
    }

    fun parseTime(t: String): Pair<Int, Int>? {
        val s = numberize(t)
        fun fin(h0: Int, m: Int): Pair<Int, Int>? {
            var h = h0
            if (h < 12 && (t.contains("aksam") || t.contains("ogleden sonra"))) h += 12
            return if (h in 0..23 && m in 0..59) Pair(h, m) else null
        }
        Regex("""(\d{1,2})\s*[:.]\s*(\d{2})""").find(s)?.let { return fin(it.groupValues[1].toInt(), it.groupValues[2].toInt()) }
        Regex("""(\d{1,2})\s+bucuk""").find(s)?.let { return fin(it.groupValues[1].toInt(), 30) }
        Regex("""\b(\d{1,2})\s+(\d{2})\b""").find(s)?.let { return fin(it.groupValues[1].toInt(), it.groupValues[2].toInt()) }
        Regex("""\b(\d{1,2})\b""").find(s)?.let { return fin(it.groupValues[1].toInt(), 0) }
        return null
    }
}

enum class K { NORMAL, SLEEP, STOP, CHAT, ENDCHAT, UNKNOWN }
data class Out(val text: String, val kind: K = K.NORMAL)

/** Sesli komutların işlendiği yer. */
class Commands(private val ctx: Context) {
    private var torch = false
    private val jokes = listOf(
        "Bir yazılımcı neden gözlük takar? Çünkü C diyezi göremez efendim.",
        "Bilgisayar neden üşümez? Çünkü her zaman Windows'u açıktır efendim.",
    )

    suspend fun run(raw: String, chat: Boolean): Out {
        val t = Tr.fold(raw)
        val w = t.split(" ")
        val compact = t.replace(" ", "")
        fun has(prefix: String) = w.any { it.startsWith(prefix) }
        val locked = ctx.getSystemService(KeyguardManager::class.java).isDeviceLocked
        val unlock = Out("Bu işlem için telefonunuzun kilidini açmanız gerekiyor efendim.")

        return when {
            has("uyku") || has("uyu") -> Out("Uyku moduna geçiyorum efendim.", K.SLEEP)
            t.contains("kendini kapat") -> Out("Kendimi kapatıyorum efendim. Hoşça kalın.", K.STOP)
            chat && (t.contains("sohbeti bitir") || t.contains("sohbet bitti")) ->
                Out("Sohbeti bitirdim efendim.", K.ENDCHAT)
            has("alarm") || has("uyandir") -> if (locked) unlock else alarm(t)
            calc(t) != null -> calc(t)!!
            t.contains("fener") || has("flas") || has("isik") -> torchCmd(w)
            has("saat") -> {
                val c = Calendar.getInstance()
                val h = c.get(Calendar.HOUR_OF_DAY); val m = c.get(Calendar.MINUTE)
                Out("Saat " + Tr.clock(h, m) + (if (m == 0) " tam" else "") + " efendim.")
            }
            t.contains("hava") -> Out(weather())
            has("pil") || has("sarj") || has("batarya") -> battery()
            has("ses") -> volume(w)
            compact.contains("youtube") || compact.contains("yutub") || compact.contains("utub") ->
                if (w.contains("kapat")) noClose() else if (locked) unlock else app("com.google.android.youtube", "YouTube")
            compact.contains("spotify") || compact.contains("spotifay") || compact.contains("spotifi") ->
                if (w.contains("kapat")) noClose() else if (locked) unlock else app("com.spotify.music", "Spotify")
            has("ayar") -> if (locked) unlock else Out(open(Intent(android.provider.Settings.ACTION_SETTINGS), "Ayarlar"))
            has("sohbet") -> Out("Tabii efendim, sizi dinliyorum. Bitirmek için sohbeti bitir deyin.", K.CHAT)
            chat && Prefs.cfg.value.apiKey.isBlank() && !Prefs.cfg.value.freeAi -> Out(chatReply(t))
            else -> Out("Bu komutu anlayamadım efendim.", K.UNKNOWN)
        }
    }

    private fun noClose() = Out("Uygulamaları kapatamıyorum efendim.")

    private val history = ArrayList<Pair<String, String>>()

    /** Anahtar gerektirmeyen ücretsiz üçüncü taraf servis (Pollinations). Kararlılığı garanti değildir. */
    private fun askFree(text: String): Out = try {
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
        val sys = "Sen JARVIS adlı Türkçe sesli asistansın. Kullanıcıya efendim diye hitap et. " +
            "En fazla üç kısa cümleyle cevap ver; markdown, madde işareti ve emoji kullanma."
        val c = URL("https://text.pollinations.ai/" + enc(text) + "?model=openai&system=" + enc(sys)).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 25000
        val code = c.responseCode
        if (code != 200) {
            c.disconnect()
            Out("Ücretsiz yapay zekâ servisi şu an cevap vermiyor efendim, kod $code.")
        } else {
            val r = c.inputStream.bufferedReader().use { it.readText() }.trim()
            c.disconnect()
            if (r.isBlank() || (r.startsWith("{") && r.contains("error"))) Out("Ücretsiz yapay zekâ servisi cevap veremedi efendim.")
            else Out(r.take(600))
        }
    } catch (e: Exception) {
        Out("Yapay zekâ servisine ulaşamadım efendim. İnternet bağlantınızı kontrol edin.")
    }

    /** Yerleşik komutlara uymayan her şey ChatGPT'ye (OpenAI API) sorulur. Anahtar yoksa UNKNOWN döner. */
    suspend fun ask(text: String): Out = withContext(Dispatchers.IO) {
        val cfg = Prefs.cfg.value
        if (cfg.apiKey.isBlank()) {
            return@withContext if (cfg.freeAi) askFree(text) else Out("Bu komutu anlayamadım efendim.", K.UNKNOWN)
        }
        try {
            val msgs = JSONArray()
            msgs.put(
                JSONObject().put("role", "system").put(
                    "content",
                    "Sen JARVIS adlı Türkçe sesli asistansın. Kullanıcıya efendim diye hitap et. " +
                        "Cevapların sesli okunacak: en fazla üç kısa cümle yaz; madde işareti, markdown, emoji ve uzun sayı listesi kullanma."
                )
            )
            for ((r, c) in history.takeLast(8)) msgs.put(JSONObject().put("role", r).put("content", c))
            msgs.put(JSONObject().put("role", "user").put("content", text))
            val body = JSONObject()
                .put("model", cfg.model.ifBlank { "gpt-4o-mini" })
                .put("messages", msgs)
                .put("max_tokens", 200)
            val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 25000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer " + cfg.apiKey.trim())
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code != 200) {
                c.disconnect()
                return@withContext Out(
                    when (code) {
                        401 -> "ChatGPT API anahtarı geçersiz efendim."
                        429 -> "ChatGPT kullanım limiti ya da bakiyeniz doldu efendim."
                        else -> "ChatGPT hata verdi efendim, kod $code."
                    }
                )
            }
            val resp = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val answer = JSONObject(resp).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim()
            history.add("user" to text)
            history.add("assistant" to answer)
            while (history.size > 12) history.removeAt(0)
            Out(answer)
        } catch (e: Exception) {
            Out("ChatGPT'ye ulaşamadım efendim. İnternet bağlantınızı kontrol edin.")
        }
    }

    /** "10 çarpı 20", "yirmi artı otuz", "100 bölü 4" gibi tek işlemlik hesaplar. */
    private fun calc(t: String): Out? {
        val s = Tr.numberize(t)
        val m = Regex("""(\d+(?:\.\d+)?)\s*(arti|carpi|kere|eksi|bolu)\s*(\d+(?:\.\d+)?)""").find(s) ?: return null
        val a = m.groupValues[1].toDouble()
        val b = m.groupValues[3].toDouble()
        val op = m.groupValues[2]
        if (op == "bolu" && b == 0.0) return Out("Sıfıra bölemem efendim.")
        val r = when (op) {
            "arti" -> a + b
            "eksi" -> a - b
            "bolu" -> a / b
            else -> a * b
        }
        fun f(x: Double) = if (x == Math.floor(x) && Math.abs(x) < 1e12) x.toLong().toString() else String.format(Tr.TR, "%.2f", x)
        val word = when (op) { "arti" -> "artı"; "eksi" -> "eksi"; "bolu" -> "bölü"; else -> "çarpı" }
        return Out(f(a) + " " + word + " " + f(b) + " eşittir " + f(r) + " efendim.")
    }

    private fun chatReply(t: String): String = when {
        t.contains("nasilsin") -> "İyiyim efendim, sistemlerim sorunsuz çalışıyor. Siz nasılsınız?"
        t.contains("adin ne") || t.contains("kimsin") -> "Ben JARVIS, kişisel asistanınızım efendim."
        t.contains("tesekkur") || t.contains("sag ol") -> "Rica ederim efendim."
        t.contains("merhaba") || t.contains("selam") -> "Merhaba efendim, size nasıl yardımcı olabilirim?"
        t.contains("gunaydin") -> "Günaydın efendim."
        t.contains("iyi geceler") -> "İyi geceler efendim."
        t.contains("espri") || t.contains("fikra") -> jokes.random()
        t.contains("ne yapabilirsin") -> "Saati, havayı ve pil durumunu söyleyebilir; feneri, sesi ve alarmı yönetebilir; YouTube, Spotify ve ayarları açabilirim efendim."
        else -> "Bunu henüz anlayamıyorum efendim, sohbet yeteneklerim sınırlı."
    }

    private fun torchCmd(w: List<String>): Out {
        val off = w.any { it.startsWith("kapat") || it.startsWith("sondur") || it == "kapa" }
        val on = w.any { it == "ac" || it.startsWith("yak") || it.startsWith("calistir") }
        val target = if (off) false else if (on) true else !torch
        return Out(try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) "Bu cihazda fener bulamadım efendim."
            else {
                cm.setTorchMode(id, target); torch = target
                if (target) "Fener açıldı efendim." else "Fener kapatıldı efendim."
            }
        } catch (e: Exception) {
            "Fenere şu an erişemiyorum efendim."
        })
    }

    private fun battery(): Out {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return Out("Pil seviyeniz yüzde " + Tr.num(level) + (if (bm.isCharging) ", şarj oluyor" else "") + " efendim.")
    }

    private fun volume(w: List<String>): Out {
        val am = ctx.getSystemService(AudioManager::class.java)
        val up = w.any { it.startsWith("artir") || it.startsWith("arttir") || it.startsWith("yuksel") || it == "ac" }
        val down = w.any { it.startsWith("azalt") || it.startsWith("kis") || it.startsWith("dusur") || it.startsWith("alcalt") }
        try {
            if (up || down) {
                val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0)
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
            }
        } catch (e: Exception) {
            return Out("Ses ayarına dokunamadım efendim.")
        }
        val pct = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return Out("Ses seviyesi yüzde " + Tr.num(pct) + " efendim.")
    }

    private fun app(pkg: String, label: String): Out {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return Out("$label yüklü değil efendim.")
        return Out(open(i, label))
    }

    private fun alarm(t: String): Out {
        val time = Tr.parseTime(t)
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
        if (time != null) {
            i.putExtra(AlarmClock.EXTRA_HOUR, time.first)
            i.putExtra(AlarmClock.EXTRA_MINUTES, time.second)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        val r = open(i, "Alarm")
        return if (time != null && Bus.appVisible) Out("Saat " + Tr.clock(time.first, time.second) + " için alarm kuruyorum efendim.")
        else if (time == null && Bus.appVisible) Out("Saati anlayamadım, alarm ekranını açıyorum efendim.")
        else Out(r)
    }

    /** Android, arka plandaki uygulamaların ekran açmasını engeller; bu yüzden dokunulabilir bildirim bırakırız. */
    private fun open(intent: Intent, label: String): String {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Bus.appVisible) {
            return try { ctx.startActivity(intent); "$label açılıyor efendim." } catch (e: Exception) { "$label açılamadı efendim." }
        }
        val pi = PendingIntent.getActivity(
            ctx, label.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        Notif.tap(ctx, "$label için dokunun", pi)
        return "Android arka plandan uygulama açmama izin vermiyor efendim. $label için bildirime dokunun."
    }

    private suspend fun weather(): String = withContext(Dispatchers.IO) {
        try {
            val city = Prefs.cfg.value.city
            val g = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=tr&name=" + URLEncoder.encode(city, "UTF-8")))
            val loc = g.getJSONArray("results").getJSONObject(0)
            val f = JSONObject(
                get(
                    "https://api.open-meteo.com/v1/forecast?current=temperature_2m,weather_code&timezone=auto&latitude=" +
                        loc.getDouble("latitude") + "&longitude=" + loc.getDouble("longitude")
                )
            ).getJSONObject("current")
            val deg = Math.round(f.getDouble("temperature_2m")).toInt()
            "${loc.getString("name")} için hava " + desc(f.getInt("weather_code")) + ", sıcaklık " + Tr.num(deg) + " derece efendim."
        } catch (e: Exception) {
            "Hava durumuna ulaşamadım efendim. İnternet bağlantınızı ve ayarlardaki şehri kontrol edin."
        }
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 6000
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    private fun desc(code: Int) = when (code) {
        0 -> "açık"; 1 -> "çoğunlukla açık"; 2 -> "parçalı bulutlu"; 3 -> "kapalı"
        45, 48 -> "sisli"
        in 51..57 -> "çiseliyor"
        in 61..67 -> "yağmurlu"
        in 71..77, 85, 86 -> "karlı"
        in 80..82 -> "sağanak yağışlı"
        95, 96, 99 -> "gök gürültülü fırtınalı"
        else -> "değişken"
    }
}

object Notif {
    private const val CH = "jarvis_status"
    private const val CH2 = "jarvis_action"

    fun channels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "JARVIS durumu", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH2, "JARVIS işlemleri", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun svc(ctx: Context, a: String) = PendingIntent.getService(
        ctx, a.hashCode(), Intent(ctx, JarvisService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun status(ctx: Context, s: JState): Notification {
        val text = when (s) {
            JState.WAITING -> "Mikrofon açık • \"JARVIS\" demenizi bekliyor"
            JState.LISTENING -> "Mikrofon açık • Sizi dinliyor"
            JState.PROCESSING -> "İşleniyor"
            JState.SPEAKING -> "Konuşuyor"
            JState.SLEEPING -> "Uykuda • Mikrofon kapalı"
            JState.PAUSED -> "Ekran kapalı • Dinleme duraklatıldı"
            JState.OFF -> "Kapalı"
        }
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
        if (s == JState.SLEEPING || s == JState.PAUSED) b.addAction(0, "Uyandır", svc(ctx, A_START))
        else b.addAction(0, "Uyku", svc(ctx, A_SLEEP))
        b.addAction(0, "Kapat", svc(ctx, A_STOP))
        return b.build()
    }

    fun tap(ctx: Context, text: String, pi: PendingIntent) {
        val n = NotificationCompat.Builder(ctx, CH2)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(2, n)
    }
}
